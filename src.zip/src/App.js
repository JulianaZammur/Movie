import './App.css';
import Sensei from './components/Sensei.js';

function App() {
  return (
    <div>
      <Sensei />
    </div>
  );
}

export default App;
